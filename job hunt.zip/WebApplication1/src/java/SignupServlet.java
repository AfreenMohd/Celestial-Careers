//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/SignupServlet")
//public class SignupServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        // Retrieve parameters from the form
//        String username = request.getParameter("username");
//        String password = request.getParameter("password");
//        String firstname = request.getParameter("firstname");
//        String lastname = request.getParameter("lastname");
//        String emailid = request.getParameter("emailid");
//        String countrycode = request.getParameter("countrycode");
//        String phonenum = request.getParameter("phonenum");
//        String gender = request.getParameter("gender");
//        String skills = request.getParameter("skills");
//
//
//
//        Connection conn = null;
//        PreparedStatement pstmt = null;
//
//        try {
//            // Load JDBC driver
//            Class.forName("com.mysql.cj.jdbc.Driver");
//
//            // Establish connection
//            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobhunt", "root", "Afreen@2108");
//
//            // Prepare SQL query to insert data into database
//            String sql = "INSERT INTO users (username, password, firstname, lastname, emailid, countrycode, phonenum, gender, skills) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
//            pstmt.setString(1, username);
//            pstmt.setString(2, password); // In a real application, hash the password before storing
//            pstmt.setString(3, firstname);
//            pstmt.setString(4, lastname);
//            pstmt.setString(5, emailid);
//            pstmt.setString(6, countrycode);
//            pstmt.setString(7, phonenum);
//            pstmt.setString(8, gender);
//            pstmt.setString(9, skills);
//            pstmt.executeUpdate();
//
//
//            // Execute the query
//            int rowsAffected = pstmt.executeUpdate();
//
//            // Check if the insertion was successful
//            if (rowsAffected > 0) {
//                // Redirect to home1.html after successful insertion
//                response.sendRedirect("login.html");
//            } else {
//                // Handle failure to insert data
//                response.getWriter().println("Failed to insert data into database.");
//                response.sendRedirect("signup.html");
//            }
//        } catch (ClassNotFoundException | SQLException e) {
//            // Handle errors
//            e.printStackTrace();
//            response.getWriter().println("Error: " + e.getMessage());
//        } finally {
//            // Close resources
//            try {
//                if (pstmt != null) pstmt.close();
//                if (conn != null) conn.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String emailid = request.getParameter("emailid");
        String countrycode = request.getParameter("countrycode");
        String phonenum = request.getParameter("phonenum");
        String gender = request.getParameter("gender");
        String skills = request.getParameter("skills");

        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobhunt", "root", "Afreen@2108");

            pstmt = con.prepareStatement("INSERT INTO users (username, password, firstname, lastname, emailid, countrycode, phonenum, gender, skills) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pstmt.setString(1, username);
            pstmt.setString(2, password); // In a real application, hash the password before storing
            pstmt.setString(3, firstname);
            pstmt.setString(4, lastname);
            pstmt.setString(5, emailid);
            pstmt.setString(6, countrycode);
            pstmt.setString(7, phonenum);
            pstmt.setString(8, gender);
            pstmt.setString(9, skills);
            pstmt.executeUpdate();

            response.getWriter().println("Registration successful");
            response.sendRedirect("login.html"); // Redirect to success page or homepage
        } catch (ClassNotFoundException | SQLException e) {
            response.getWriter().println("ERROR: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                response.getWriter().println("ERROR closing resources: " + e.getMessage());
            }
        }
    }
}
